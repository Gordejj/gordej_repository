﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Library;
using GOSTLibrary;
using System.IO;

namespace Cryptography
{
    public partial class Form1 : Form
    {
        private string source;
        private Stream signed;
        private CypherRSA rsa;

        private string[] outputTable = { "0000", "0001", "0010", "0011", "0100", "0101", "0110", "0111", "1000", "1001", "1010", "1011", "1100", "1101", "1110", "1111" };

        public Form1()
        {
            InitializeComponent();
        }

        private string getOutput(byte[] buffer)
        {
            string output = "";

            for(int i = 0; i < buffer.Length; i++)
            {
                string buf = "";
                byte temp = buffer[i];
                for(int k = 0; k < 8; k++)
                {
                    if ((temp & (1 << k)) != 0)
                    {
                        buf += "1";
                    }
                    else
                    {
                        buf += "0";
                    }
                }

                string left = "", right = "";
                for(int k = 0; k < 4; k++)
                {
                    right += buf[k];
                    left += buf[k + 4];
                }
                int indexLeft = Array.IndexOf(outputTable, left);
                string outputLeft = Convert.ToString((Int32)indexLeft, 16);
                int indexRight = Array.IndexOf(outputTable, right);
                string outputRight = Convert.ToString((Int32)indexRight, 16);

                output += outputLeft + outputRight + " ";

            }

            return output;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            source = textBox1.Text;
            string key = "{C42B9D23-F6F8-4AAA-8D1E-00F3A488A507}";
            GOST28147_89 buffer = new GOST28147_89();
            MemoryStream sourceStream = new MemoryStream(Encoding.Default.GetBytes(source));
            MemoryStream encryptedOutputStream = new MemoryStream();
            MemoryStream decryptedOutputStream = new MemoryStream();

            buffer.dataToGost(sourceStream, key, encryptedOutputStream);

            byte[] bufRead1 = new byte[encryptedOutputStream.Length];
            encryptedOutputStream.Position = 0;
            encryptedOutputStream.Read(bufRead1, 0, (int)encryptedOutputStream.Length);

            textBox2.Text = getOutput(bufRead1);

            buffer.gostToData(encryptedOutputStream, key, decryptedOutputStream);

            byte[] bufRead2 = new byte[decryptedOutputStream.Length];
            decryptedOutputStream.Position = 0;
            decryptedOutputStream.Read(bufRead2, 0, (int)decryptedOutputStream.Length);

            textBox10.Text = Encoding.Default.GetString(bufRead2);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            source = textBox4.Text;
            RSAClass RSA = new RSAClass();
            MemoryStream sourceStream = new MemoryStream(Encoding.Default.GetBytes(source));
            MemoryStream encryptedStream = new MemoryStream();
            MemoryStream decryptedStream = new MemoryStream();

            RSA.RSADataCryp(sourceStream, encryptedStream);

            byte[] bufRead1 = new byte[encryptedStream.Length];
            encryptedStream.Position = 0;
            encryptedStream.Read(bufRead1, 0, (int)encryptedStream.Length);

            textBox3.Text = getOutput(bufRead1);

            RSA.RSADataDecrypt(encryptedStream, decryptedStream);

            byte[] bufRead2 = new byte[decryptedStream.Length];
            decryptedStream.Position = 0;
            decryptedStream.Read(bufRead2, 0, (int)decryptedStream.Length);

            textBox11.Text = Encoding.Default.GetString(bufRead2);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            source = textBox6.Text;
            MemoryStream sourceStream = new MemoryStream(source.ConvertToByteArray());
            MemoryStream hashedStream = new MemoryStream();
            CypherMD5 md5 = new CypherMD5();

            md5.HashStream(sourceStream, hashedStream);
            byte[] buf = new byte[hashedStream.Length];
            hashedStream.Read(buf, 0, (int)hashedStream.Length);

            textBox5.Text = getOutput(buf);
        }

        private void button4_Click(object sender, EventArgs e)
        {
            source = textBox8.Text;
            signed = new MemoryStream();
            rsa = new CypherRSA();
            MemoryStream input = new MemoryStream(Encoding.Default.GetBytes(source));
            rsa.Sign(input, signed);

            byte[] bufRead1 = new byte[signed.Length];
            signed.Position = 0;
            signed.Read(bufRead1, 0, (int)signed.Length);
            signed.Position = 0;

            textBox7.Text = getOutput(bufRead1);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (rsa.Verify(signed))
            {
                textBox9.Text = "Подпись верна!";
            }
            else
            {
                textBox9.Text = "Подпись не верна!";
            }
        }
    }
}
