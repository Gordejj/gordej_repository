﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using CryptoLibrary;
using System.IO;
using System.Text;

namespace BlowfishTest
{
    [TestClass]
    public class UnitTest1
    {

        private string key = "{C42B9D23-F6F8-4AAA-8D1E-00F3A488A507}";
        private string value = "Test";
        private string encrypted = "J5APsWH6FOs=";

        [TestMethod]
        public void EncipherEqualEncryptedConstant()
        {
            Blowfish blowfish = new Blowfish(key);
            Assert.AreEqual(blowfish.Encipher(value), encrypted);
        }

        [TestMethod]
        public void DecipherEqualDecryptedConstant()
        {
            Blowfish blowfish = new Blowfish(key);
            Assert.AreEqual(blowfish.Decipher(encrypted), value);
        }

        [TestMethod]
        public void EncipherAndDecipherOfConstantEqualDecipherConstant()
        {
            Blowfish blowfish = new Blowfish(key);
            Assert.AreEqual(blowfish.Decipher(blowfish.Encipher(value)), blowfish.Decipher(encrypted));
        }

        [TestMethod]
        public void ConstantEqualDecrypted()
        {
            CypherBlowfish buffer = new CypherBlowfish();
            MemoryStream stringStream = new MemoryStream(Encoding.Default.GetBytes(value));
            MemoryStream encryptedOutputStream = new MemoryStream();
            MemoryStream decryptedOutputStream = new MemoryStream();
            buffer.dataToBlowfish(stringStream, key, encryptedOutputStream);
            buffer.blowfishToData(encryptedOutputStream, key, decryptedOutputStream);
            string encryptedString = Encoding.Default.GetString(encryptedOutputStream.ToArray()).TrimEnd('\0');
            string decryptedString = Encoding.Default.GetString(decryptedOutputStream.ToArray()).TrimEnd('\0');
            Assert.AreEqual(value, decryptedString);
        }
    }
}
