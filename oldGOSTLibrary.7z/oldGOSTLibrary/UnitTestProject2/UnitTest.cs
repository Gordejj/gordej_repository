﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Text;
using System.IO;

namespace UnitTestProject2
{
    [TestClass]
    public class UnitTest
    {
        //Проверяет, получаем ли мы строку, эквивалентную исходной, после зашифровки и расшифровки
        //По сути, полное тестирование, но в случае успешного прохождения теста EncryptedEqualeStandard 
        //автоматически становится проверкой только расшифровки
        [TestMethod]
        public void GOSTSourceEqualeResult()
        {
            GOSTLibrary.cypherGOSTclass bufferGOST = new GOSTLibrary.cypherGOSTclass();
            string sourceDataString = "test";
            MemoryStream sourceDataStream = new MemoryStream(Encoding.Default.GetBytes(sourceDataString));
            MemoryStream encryptedDataStream = bufferGOST.dataToGost(sourceDataStream);
            MemoryStream decryptedDataStream = bufferGOST.gostToData(encryptedDataStream);
            string decryptedDataString = Encoding.Default.GetString(decryptedDataStream.ToArray()).TrimEnd('\0');
            Assert.AreEqual(sourceDataString, decryptedDataString);
        }

        //Проверка соответствия зашифрованной строки той, что должна была получиться при правильной реализации алгоритма
        [TestMethod]
        public void GOSTEncryptedEqualeStandard()
        {
            GOSTLibrary.cypherGOSTclass bufferGOST = new GOSTLibrary.cypherGOSTclass();
            string sourceDataString = "test";
            MemoryStream sourceDataStream = new MemoryStream(Encoding.Default.GetBytes(sourceDataString));
            MemoryStream encryptedDataStream = bufferGOST.dataToGost(sourceDataStream);
            string encryptedDataString = Encoding.Default.GetString(encryptedDataStream.ToArray()).TrimEnd('\0');
            Assert.AreEqual(encryptedDataString, "i#;xж\u0014г'");
        }

        //Проверяет, получаем ли мы строку, эквивалентную исходной, после зашифровки и расшифровки
        //По сути, полное тестирование, но в случае успешного прохождения теста EncryptedEqualeStandard 
        //автоматически становится проверкой только расшифровки
        [TestMethod]
        public void RSASourceEqualeResult()
        {
            GOSTLibrary.cypherRSAclass bufferRSA = new GOSTLibrary.cypherRSAclass();
            GOSTLibrary.RSAKey publicKey = new GOSTLibrary.RSAKey(17, 249);
            GOSTLibrary.RSAKey privateKey = new GOSTLibrary.RSAKey(29, 249);
            Stream encryptedDataStream = new MemoryStream();
            Stream decryptedDataStream = new MemoryStream();
            string sourceDataString = "test";
            MemoryStream sourceDataStream = new MemoryStream(Encoding.Default.GetBytes(sourceDataString));
            bufferRSA.dataToRsa(sourceDataStream, encryptedDataStream, publicKey);
            encryptedDataStream.Position = 0;
            bufferRSA.rsaToData(encryptedDataStream, decryptedDataStream, privateKey);
            StreamReader reader = new StreamReader(decryptedDataStream);
            decryptedDataStream.Position = 0;
            string decryptedDataString = reader.ReadToEnd();
            Assert.AreEqual(sourceDataString, decryptedDataString);
        }

        //Проверка соответствия зашифрованной строки той, что должна была получиться при правильной реализации алгоритма
        [TestMethod]
        public void RSAEncryptedEqualeStandard()
        {
            GOSTLibrary.cypherRSAclass bufferRSA = new GOSTLibrary.cypherRSAclass();
            GOSTLibrary.RSAKey publicKey = new GOSTLibrary.RSAKey(17, 249);
            GOSTLibrary.RSAKey privateKey = new GOSTLibrary.RSAKey(29, 249);
            Stream encryptedDataStream = new MemoryStream();
            string sourceDataString = "test";
            MemoryStream sourceDataStream = new MemoryStream(Encoding.Default.GetBytes(sourceDataString));
            bufferRSA.dataToRsa(sourceDataStream, encryptedDataStream, publicKey);
            encryptedDataStream.Position = 0;
            StreamReader reader = new StreamReader(encryptedDataStream);
            string encryptedDataString = reader.ReadToEnd();
            Assert.AreEqual(encryptedDataString, "_ [_");
        }
    }
}
