﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace GOSTLibrary
{
    public interface ICryptoAlgorithm
    {
        void Encrypt(Stream sourceData, Stream returnData);
        void Decrypt(Stream sourceData, Stream returnData);

    }

    public class cypherGOSTclass : ICryptoAlgorithm
    {
        //переводит осмысленную строку в строку зашифрованную
        public MemoryStream Encrypt(MemoryStream sourceData)
        {
            GOST28147_89 bufferGOST = new GOST28147_89();
            bufferGOST.kboxinit();
            byte[] encryptedData = bufferGOST.GOSTDataCrypt(sourceData.ToArray());
            MemoryStream encryptedDataStream = new MemoryStream(encryptedData);
            returnData = encryptedDataStream;
        }

        //переводит зашифрованную строку в осмысленную
        public void Decrypt(Stream sourceData, Stream returnData)
        {
            GOST28147_89 bufferGOST = new GOST28147_89();
            bufferGOST.kboxinit();
            byte[] decryptedData = bufferGOST.GOSTDataDecrypt(sourceData.ToArray());
            MemoryStream decryptedDataStream = new MemoryStream(decryptedData);
            returnData = decryptedDataStream;
        }

    }




        public class GOST28147_89
    {
        //таблица замен; в каждом ряду полный набор всех числе от 0 до 15, критерии выбора порядка в стандарте не указаны
        private readonly byte[] k8 = { 0x14, 0x04, 0x13, 0x01, 0x02, 0x15, 0x11, 0x08, 0x03, 0x10, 0x06, 0x12, 0x05, 0x09, 0x00, 0x07 };
        private readonly byte[] k7 = { 0x15, 0x01, 0x08, 0x14, 0x06, 0x11, 0x03, 0x04, 0x09, 0x07, 0x02, 0x13, 0x12, 0x00, 0x05, 0x10 };
        private readonly byte[] k6 = { 0x10, 0x00, 0x09, 0x14, 0x06, 0x03, 0x15, 0x05, 0x01, 0x13, 0x12, 0x07, 0x11, 0x04, 0x02, 0x08 };
        private readonly byte[] k5 = { 0x07, 0x13, 0x14, 0x03, 0x00, 0x06, 0x09, 0x10, 0x01, 0x02, 0x08, 0x05, 0x11, 0x12, 0x04, 0x15 };
        private readonly byte[] k4 = { 0x02, 0x12, 0x04, 0x01, 0x07, 0x10, 0x11, 0x06, 0x08, 0x05, 0x03, 0x15, 0x13, 0x00, 0x14, 0x09 };
        private readonly byte[] k3 = { 0x12, 0x01, 0x10, 0x15, 0x09, 0x02, 0x06, 0x08, 0x00, 0x13, 0x03, 0x04, 0x14, 0x07, 0x05, 0x11 };
        private readonly byte[] k2 = { 0x04, 0x11, 0x02, 0x14, 0x15, 0x00, 0x08, 0x13, 0x03, 0x12, 0x09, 0x07, 0x05, 0x10, 0x06, 0x01 };
        private readonly byte[] k1 = { 0x13, 0x02, 0x08, 0x04, 0x06, 0x15, 0x11, 0x01, 0x10, 0x09, 0x03, 0x14, 0x05, 0x00, 0x12, 0x07 };

        private byte[] k87 = new byte[256];
        private byte[] k65 = new byte[256];
        private byte[] k43 = new byte[256];
        private byte[] k21 = new byte[256];

        private static int BYTECOUNT = 4;

        //ключ
        private uint[] key = new uint[8] { 0x11111111, 0x22222222, 0x33333333, 0x44444444, 0x55555555, 0x66666666, 0x77777777, 0x88888888 };

        //Совмещение строк друг с другом, чтобы использовался байт целиком, а не только 4 бита; нужно только для ускорения работы
        public void kboxinit()
        {
            int i;
            for (i = 0; i < 256; i++)
            {
                k87[i] = (byte)(k8[i >> 4] << 4 | k7[i & 15]);
                k65[i] = (byte)(k6[i >> 4] << 4 | k5[i & 15]);
                k43[i] = (byte)(k4[i >> 4] << 4 | k3[i & 15]);
                k21[i] = (byte)(k2[i >> 4] << 4 | k1[i & 15]);
            }
        }


        //Часть «основного шага»: замена из таблицы замен и сдвиг полученного значения в сторону старших разрядов на 11 битов
        private uint Replacement(uint x)
        {
            //Реализация inline серьёзно ускоряет процесс
            x = (uint)(k87[x >> 24 & 255] << 24 | k65[x >> 16 & 255] << 16 |
                    k43[x >> 8 & 255] << 8 | k21[x & 255]);

            return x << 11 | x >> (32 - 11);
        }

        //конвертирование byte[] в uint
        public uint SmallToBig(byte[] data)
        {
            uint result = 0;
            for (int i = 0; i < data.Length; i++)
                result = (uint)(result | (data[i] << (8 * i)));

            return result;
        }

        //конвертирование uint в byte[]
        public void BigToSmall(int startPosition, int QTY, byte[] data, uint Big)
        {
            for (int i = 0; i < QTY; i++)
            {
                data[startPosition + i] = (byte)((Big & (0x000000FF << 8 * i)) >> 8 * i);
            }
        }
        
        //зашифровка блока байт
        public void GOSTBlockCrypt(uint[] input, uint[] output, uint[] key)
        {
            uint n1, n2;

            n1 = input[0];
            n2 = input[1];

            //Вместо перемены местами блоков, как это указано в стандарте, просто меняем имена; результат тот же
            for (int i = 0; i < 3; i++)
            {
                for (int k = 0; k < 7; k = k + 2)
                {
                    n2 ^= Replacement(n1 + key[k]);
                    n1 ^= Replacement(n2 + key[k+1]);
                }
            }

            for (int k = 7; k > 0; k = k - 2)
            {
                n2 ^= Replacement(n1 + key[k]);
                n1 ^= Replacement(n2 + key[k - 1]);
            }

            output[0] = n2;
            output[1] = n1;
        }

        //Расшифровка блока байт
        public void GOSTBlockDecrypt(uint[] input, uint[] output, uint[] key)
        {
            uint n1, n2;

            n1 = input[0];
            n2 = input[1];

            for (int k = 0; k < 7; k = k + 2)
            {
                n2 ^= Replacement(n1 + key[k]);
                n1 ^= Replacement(n2 + key[k + 1]);
            }

            for (int i = 0; i < 3; i++)
            {
                for (int k = 7; k > 0; k = k - 2)
                {
                    n2 ^= Replacement(n1 + key[k]);
                    n1 ^= Replacement(n2 + key[k - 1]);
                }
            }

            output[0] = n2;
            output[1] = n1;
        }

        //Зашифровывает массив байт, предварительно разделяя его на описанные в стандарте блоки
        public byte[] GOSTDataCrypt(byte[] data)
        {
            //Дозаполяем массив нулями, если он не соответствует размерам, подходящим для реализации простой замены
            if (data.Length % 4 != 0)
            {
                int lenght = (data.Length / 4) * 4 + 4;
                Array.Resize<byte>(ref data, lenght);
            }
            if ((data.Length / 4) % 2 != 0)
            {
                Array.Resize<byte>(ref data, data.Length + 4);
            }


            byte[] tempSmallData = new byte[BYTECOUNT];
            uint[] tempBigData = new uint[2];
            uint[] cryptedBigData = new uint[2];
            byte[] cryptedSmallData = new byte[data.Length];
            int k = 0;
            int j = 0;
            int p = 0;

            for (int i = 0; i < data.Length; i++)
            {
                tempSmallData[k] = data[i];
                if (k == 3)
                {
                    k = 0;
                    tempBigData[j] = SmallToBig(tempSmallData);
                    j++;
                    if (j == 2)
                    {
                        j = 0;
                        //непосредственно зашифровка выделенного блока
                        GOSTBlockCrypt(tempBigData, cryptedBigData, key);
                        for (int m = 0; m < cryptedBigData.Length; m++)
                        {
                            BigToSmall(p, BYTECOUNT, cryptedSmallData, cryptedBigData[m]);
                            p += BYTECOUNT;
                        }
                    }
                }
                else
                {
                    k++;
                }
            }
            return cryptedSmallData;
        }

        //Расшифровывает массив байт, предварительно разделяя его на описанные в стандарте блоки
        public byte[] GOSTDataDecrypt(byte[] data)
        {
            if (data.Length % 4 != 0)
            {
                int lenght = (data.Length / 5) * 4 + 4;
                Array.Resize<byte>(ref data, lenght);
            }

            byte[] tempSmallData = new byte[BYTECOUNT];
            uint[] tempBigData = new uint[2];
            uint[] decryptedBigData = new uint[2];
            byte[] decryptedSmallData = new byte[data.Length];
            int k = 0;
            int j = 0;
            int p = 0;

            for (int i = 0; i < data.Length; i++)
            {
                tempSmallData[k] = data[i];
                if (k == 3)
                {
                    k = 0;
                    tempBigData[j] = SmallToBig(tempSmallData);
                    j++;
                    if (j == 2)
                    {
                        j = 0;
                        //непосредственно расшифровка выделенного блока
                        GOSTBlockDecrypt(tempBigData, decryptedBigData, key);
                        for (int m = 0; m < decryptedBigData.Length; m++)
                        {
                            BigToSmall(p, BYTECOUNT, decryptedSmallData, decryptedBigData[m]);
                            p += BYTECOUNT;
                        }
                    }
                }
                else
                {
                    k++;
                }
            }
            return decryptedSmallData;
        }

    }
}
